using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // ����UI�����ռ�

public class scoredisplay : MonoBehaviour
{
    public Text scoreText; // ����UI Text���
    public Text valueText; // ����UI Text���

    private int score = 0;  // ˽�з�������
    private int value = 100;
    public static scoredisplay Instance; //���屾��

    // Start is called before the first frame update
    void Awake()
    {
        Instance = this;
        UpdateScoreText();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // ���ô˷��������ӷ���
    public void AddScore(int points)
    {
        score += points;
        UpdateScoreText();
    }

    public void DelValue(int points)
    {
        value -= points;
        UpdateValueText();
        //
        if (value == 0)
            Application.Quit();

    }


    // ����UI Text������ı�
    private void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }
        else
        {
            Debug.LogError("Score Text is not assigned!");
        }
    }

    private void UpdateValueText()
    {
        if (valueText != null)
        {
            valueText.text = "Value: " + value;
        }
        else
        {
            Debug.LogError("Value Text is not assigned!");
        }
    }

}
