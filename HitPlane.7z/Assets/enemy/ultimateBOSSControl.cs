using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ultimateBOSSControl : MonoBehaviour
{
    private float timer = 0;
    public GameObject EnemyPre; //����

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > 2)//2s����һ��
        {
            timer = 0;

            //��һ���ӵ�
            float angleOffset0 = 180.0f; // ������Ҫ�����Ƕ�ƫ����
            Quaternion leftRotation0 = Quaternion.Euler(0, 0, angleOffset0);
            GameObject bullet0 = Instantiate(EnemyPre, transform.position, transform.rotation * leftRotation0);
            Rigidbody2D rb0 = bullet0.GetComponent<Rigidbody2D>();
            rb0.velocity = bullet0.transform.up * 0.5f;

            //�ڶ����ӵ�
            float angleOffset = 165.0f; // ������Ҫ�����Ƕ�ƫ����
            Quaternion leftRotation = Quaternion.Euler(0, 0, angleOffset);
            GameObject bullet2 = Instantiate(EnemyPre, transform.position, transform.rotation * leftRotation);
            Rigidbody2D rb2 = bullet2.GetComponent<Rigidbody2D>();
            rb2.velocity = bullet2.transform.up * 0.5f;

            //�������ӵ�
            Quaternion rightRotation = Quaternion.Euler(0, 0, -angleOffset);
            GameObject bullet3 = Instantiate(EnemyPre, transform.position, transform.rotation * rightRotation);
            Rigidbody2D rb3 = bullet3.GetComponent<Rigidbody2D>();
            rb3.velocity = bullet3.transform.up * 0.5f;

        }
    }
}
