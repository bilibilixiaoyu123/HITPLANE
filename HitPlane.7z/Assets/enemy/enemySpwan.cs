using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemySpwan : MonoBehaviour
{
    public GameObject EnemyPre; //����
    private float timer = 0;

    public GameObject scoreManager;
    private scoredisplay sD;

    // Start is called before the first frame update
    void Start()
    {
        sD = scoredisplay.Instance.GetComponent<scoredisplay>();
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > 2)//2s����һ��
        {
            timer = 0;
            Instantiate(EnemyPre, transform.position, transform.rotation); //��������
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Bullet")//�����м�10��
        {
            sD.AddScore(10);
            Destroy(collision.gameObject);
        }
    }
}
