using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy1Control : MonoBehaviour
{
    private Vector3 dir;//����

    public GameObject scoreManager;

    private scoredisplay sD;
    // Start is called before the first frame update
    void Start()
    {
        sD = scoredisplay.Instance.GetComponent<scoredisplay>();
        dir = heroControl.Instance.transform.position - transform.position;//��ʼ����
    }

    // Update is called once per frame
    void Update()
    {
        //�ƶ�
        transform.position += dir * Time.deltaTime * 0.2f;

        if (transform.position.y < -5)//�ɳ�����������
        {
            Destroy(gameObject);
        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Bullet")//���˱��ӵ���������
        {
            sD.AddScore(1);
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }

    
}
